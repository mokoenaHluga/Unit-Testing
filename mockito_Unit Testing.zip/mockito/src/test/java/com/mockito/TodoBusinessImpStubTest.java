package com.mockito;

import com.service.TodoService;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class TodoBusinessImpStubTest {

    TodoService todoMock = mock(TodoService.class);

    @Test
    public void testRetrieveTodosRelatedStub_UsingMock() {

        List<String> mockArray = Arrays.asList("Learn Spring MVC", "Learn Spring",
                "Learn to Dance");

        when(todoMock.retrieveTodos("Dummy")).thenReturn(mockArray);
        TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoMock);

        List<String> filterTodos = todoBusinessImpl.retrieveTodosRelatedToSpring("Dummy");

        assertEquals(2, filterTodos.size());

    }

    @Test
    public void testRetrieveTodosRelatedStub_UsingBDDMock() {

        //Given
        List<String> mockArray = Arrays.asList("Learn Spring MVC", "Learn Spring",
                "Learn to Dance");

        given(todoMock.retrieveTodos("Dummy")).willReturn(mockArray);
        TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoMock);

        //When
        List<String> filterTodos = todoBusinessImpl.retrieveTodosRelatedToSpring("Dummy");

        //Then
        assertEquals(2, filterTodos.size());
        assertThat(filterTodos.size(), is(2));
    }

    @Test
    public void testDeleteTodosNotRelatedToSpringUssingBDD() {

        //Given
        List<String> mockArray = Arrays.asList("Learn Spring MVC", "Learn Spring",
                "Learn to Dance");

        given(todoMock.retrieveTodos("Dummy")).willReturn(mockArray);
        TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoMock);

        //When
        todoBusinessImpl.deleteTodosNotRelatedToSpring("Dummy");

        /**
         * Then
         This is used when you want to check if your method was called (Verify)
         * Can also check if a specific method is not called, by using the never parameter
         * You can also check how many time was the method called
         */

        // Then
        verify(todoMock).deleteTodo("Learn to Dance");
        then(todoMock).should().deleteTodo("Learn to Dance");

        verify(todoMock, never()).deleteTodo("Learn Spring MVC");
        then(todoMock).should(never()).deleteTodo("Learn Spring MVC");

        verify(todoMock, times(1)).deleteTodo("Learn to Dance");
        then(todoMock).should(never()).deleteTodo("Learn Spring");

    }

    @Test
    public void testDeleteTodosNotRelatedToSpring_UssingBDD_Argument() {

        //Declare Argument Capture
        //Define Argument capture on specific method call
        //Capture the argument

        //Check the docs for argument captor
        //Simply assist in capturing the argument used when a method is called with argument
        ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);


        //Given
        List<String> mockArray = Arrays.asList("Learn Spring MVC", "Learn Spring",
                "Learn to Dance");

        given(todoMock.retrieveTodos("Dummy")).willReturn(mockArray);
        TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoMock);

        //When
        todoBusinessImpl.deleteTodosNotRelatedToSpring("Dummy");

        then(todoMock).should().deleteTodo(stringArgumentCaptor.capture());
        assertThat(stringArgumentCaptor.getValue(), is("Learn to Dance"));

    }
}

