package com.mockito;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class in28MinutesMckito {


    @Test
    public void testTruncateAInFirst2Positions() {
        assertTrue(true);
    }
}
